<?php
// Definimos variables con los datos necesarios para la conexión
$servidor = "localhost";
$baseDatos = "the Syndicate";
$usuarioBd = "root";
$passwordBd = "Gintox@97";

// Creamos la conexión
$conexionLocalhost = mysql_connect($servidor, $usuarioBd, $passwordBd) or trigger_error(mysql_error(), E_USER_ERROR);
//$conexionLocalhost = mysqli_connect($servidor, $usuarioBd, $passwordBd) or trigger_error(mysql_error(), E_USER_ERROR);


// Definimos el cotejamiento para la conexion (igual al cotejamiento de la BD)
mysql_query("SET NAMES 'utf8'");
//mysqli_query($conexionLocalhost, "SET NAMES 'utf8'");

// Seleccionamos la base de datos por defecto para el proyecto
mysql_select_db($baseDatos, $conexionLocalhost);
//mysqli_select_db($conexionLocalhost, $baseDatos);


?>