<div class="txt_footer" id="footer">
<p style="padding-top: 45px;">Proyecto Final Aplicaciones Web<br />
  Design and Code by The Syndicate</p>
</div>