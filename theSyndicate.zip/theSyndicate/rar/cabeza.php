
    <div class="h-title">

</div>

    <div class="h-buttons">

        <ul>
        <li class="h-button"><a href="index.php">Inicio</a></li>
        <li class="h-button"><a href="#">Reinos</a></li>
        <li class="h-button"><a href="#">Clanes</a></li>
        <li class="h-button"><a href="#">Inventario</a></li>
        <li class="h-button"><a href="#">Misiones</a></li>
        <li class="h-button"><a href="Registro.php">Registro</a></li>
        <li class="h-button"><a href="#">Acerca De</a></li>

        </ul>

</div>

