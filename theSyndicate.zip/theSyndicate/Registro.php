<?php
include("conexiones/conexionLocalhost.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Registro de Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>

<div class="cuerpo">
<div class="header">

<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">

<p style="font-family: Federant; font-size: 28px; text-align: center;"> 
<strong>Por favor de no dejar espacios vacios al momento de ingresar sus datos</strong></p>

<form action="Registro.php" method="post">
<table>
		<tr>
		  <td><label for="nombre"><strong>Nombre:</strong></label></td>
		  <td><input type="text" name="nombre" placeholder="Aqui pones el nombre de tu canal."
           value="<?php if(isset($_POST['nombre'])) echo $_POST['nombre']; ?>"></td>
		</tr>
        <tr>
		  <td><label for="email"><strong>Email:</strong></label></td>
		  <td><input type="text" name="email" placeholder="Ingresa tu Correo Electronico."
           value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>"></td>
		</tr>
        <tr>
		  <td><label for="password"><strong>Password:</strong></label></td>
		  <td><input type="password" name="password"></td>
		</tr>
		<tr>
		  <td><label for="password2"><strong>Password 2:</strong></label></td>
		  <td><input type="password" name="password2"></td>
		</tr>
        <tr>
		  <td><label for="rango"><strong>Rango:</strong></label></td>
		  <td>
			 <select name="rango">
				<option value="usuario" <?php if(isset($_POST['rango']) AND $_POST['rango'] == "usuario") echo 'selected="selected"'; ?>>Usuario</option>
				<option value="admin" <?php if(isset($_POST['rango']) AND $_POST['rango'] == "admin") echo 'selected="selected"'; ?>>Administrador</option>
			 </select>
		  </td>
		</tr>
        <tr>
		  <td><label for="genero"><strong>Genero:</strong></label></td>
		  <td>
			 <select name="genero">
				<option value="hombre" <?php if(isset($_POST['genero']) AND $_POST['genero'] == "hombre") echo 'selected="selected"'; ?>>Hombre</option>
				<option value="admin" <?php if(isset($_POST['genero']) AND $_POST['genero'] == "mujer") echo 'selected="selected"'; ?>>Mujer</option>
			 </select>
		  </td>
		</tr>
        <tr>
		  <td><label for="rol"><strong>Rol:</strong></label></td>
		  <td>
			 <select name="rol">
				<option value="luchador" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "luchador") echo 'selected="selected"'; ?>>Luchador</option>
				<option value="mago" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "mago") echo 'selected="selected"'; ?>>Mago</option>
                <option value="asesino" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "asesino") echo 'selected="selected"'; ?>>Asesino</option>
                <option value="tanque" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "tanque") echo 'selected="selected"'; ?>>Tanque</option>
                <option value="soporte" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "soporte") echo 'selected="selected"'; ?>>Soporte</option>
			 </select>
		  </td>
		</tr>
        <tr>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td><input type="submit" value="Guardar usuario" name="sent" /></td>
		  <td>&nbsp;</td>
		</tr>


</table>
</form>

<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar1.php");?>


</body>
</html>