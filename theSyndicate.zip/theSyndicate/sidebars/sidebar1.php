<div id="sidebar">
<div class="sb" id="rar">

<h4 style="font-size: 20px"> Preguntas Generales </h4>
<a href="#"> ¿Es obligatorio poner el correo?</a>
<a href="#"> ¿Que requisitos necesito?</a>
<a href="#"> ¿como puedo ser administrador?</a>


</div>
</div>